my_list = ['黑马程序员', '传智播客', '黑马程序员', '传智播客', 'itheima', 'itcast', 'itheima', 'itcast', 'best']
set1 = set()
for element in my_list:
    set1.add(element)
print(f"添加后的集合元素有：{set1}")