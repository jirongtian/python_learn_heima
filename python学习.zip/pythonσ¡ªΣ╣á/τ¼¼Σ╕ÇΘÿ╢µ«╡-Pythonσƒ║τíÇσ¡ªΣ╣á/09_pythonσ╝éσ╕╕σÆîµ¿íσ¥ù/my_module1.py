__all__ = ['test_a']


def test_a(a,b):
    print(a+b)

def test_b(a,b):
    print(a-b)

# if __name__ == '__main__':
#     test_a(1, 2)