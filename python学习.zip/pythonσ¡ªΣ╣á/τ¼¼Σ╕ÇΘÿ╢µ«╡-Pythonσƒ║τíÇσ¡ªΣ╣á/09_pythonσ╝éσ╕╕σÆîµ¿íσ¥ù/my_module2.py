
def test(a,b):
    print(a-b)