sum = 0
i = 1
while i <= 100:
    sum += i
    i += 1
print("1-100累加的和是：",sum)