print("hello,world")
print("黑马程序员")